package mk.ukim.finki.mk.lab.service;

import mk.ukim.finki.mk.lab.model.Location;

import java.util.List;

public interface LocationService {
    public List<Location> findAll();
}
