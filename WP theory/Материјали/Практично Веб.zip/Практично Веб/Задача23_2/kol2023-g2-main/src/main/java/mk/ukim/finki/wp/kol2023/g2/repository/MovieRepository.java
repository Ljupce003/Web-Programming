package mk.ukim.finki.wp.kol2023.g2.repository;

import mk.ukim.finki.wp.kol2023.g2.model.Movie;

public interface MovieRepository extends JpaSpecificationRepository<Movie,Long> {
}
