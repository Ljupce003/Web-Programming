package mk.ukim.finki.wp.kol2023.g2.model;

public enum Genre {
    Action,
    Comedy,
    Horror
}
