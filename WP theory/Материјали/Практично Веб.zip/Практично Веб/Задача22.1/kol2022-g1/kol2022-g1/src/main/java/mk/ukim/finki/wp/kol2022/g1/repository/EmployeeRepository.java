package mk.ukim.finki.wp.kol2022.g1.repository;

import mk.ukim.finki.wp.kol2022.g1.model.Employee;

public interface EmployeeRepository extends JpaSpecificationRepository<Employee,Long> {
}
