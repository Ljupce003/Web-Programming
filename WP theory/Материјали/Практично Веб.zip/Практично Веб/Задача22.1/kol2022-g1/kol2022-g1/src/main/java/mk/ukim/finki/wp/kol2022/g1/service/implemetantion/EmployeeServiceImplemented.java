package mk.ukim.finki.wp.kol2022.g1.service.implemetantion;

import mk.ukim.finki.wp.kol2022.g1.model.Employee;
import mk.ukim.finki.wp.kol2022.g1.model.EmployeeType;
import mk.ukim.finki.wp.kol2022.g1.model.Skill;
import mk.ukim.finki.wp.kol2022.g1.model.exceptions.InvalidEmployeeIdException;
import mk.ukim.finki.wp.kol2022.g1.repository.EmployeeRepository;
import mk.ukim.finki.wp.kol2022.g1.repository.SkillRepository;
import mk.ukim.finki.wp.kol2022.g1.service.EmployeeService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import static mk.ukim.finki.wp.kol2022.g1.service.specifications.FieldFilterSpecification.*;


@Service
public class EmployeeServiceImplemented implements EmployeeService {

    private final EmployeeRepository employeeRepository;
    private final SkillRepository skillRepository;

    public EmployeeServiceImplemented(EmployeeRepository employeeRepository, SkillRepository skillRepository) {
        this.employeeRepository = employeeRepository;
        this.skillRepository = skillRepository;
    }

    @Override
    public List<Employee> listAll() {
        return this.employeeRepository.findAll();
    }

    @Override
    public Employee findById(Long id) {
        return this.employeeRepository.findById(id).orElseThrow(InvalidEmployeeIdException::new);
    }

    @Override
    public Employee create(String name, String email, String password, EmployeeType type, List<Long> skillId, LocalDate employmentDate) {

        List<Skill> skillList=this.skillRepository.findAllById(skillId);

        Employee employee=new Employee(name,email,password,type,skillList,employmentDate);



        return this.employeeRepository.save(employee);
    }

    @Override
    public Employee update(Long id, String name, String email, String password, EmployeeType type, List<Long> skillId, LocalDate employmentDate) {

        Employee employee=findById(id);
        List<Skill> skillList=this.skillRepository.findAllById(skillId);

        employee.setName(name);
        employee.setEmail(email);
        employee.setPassword(password);
        employee.setType(type);
        employee.setSkills(skillList);

        employee.setEmploymentDate(employmentDate);


        return this.employeeRepository.save(employee);
    }

    @Override
    public Employee delete(Long id) {
        Employee employee=findById(id);
        this.employeeRepository.delete(employee);

        return employee;
    }

    @Override
    public Page<Employee> filter(Long skillId, Integer yearsOfService, Integer pageNum, Integer pageSize) {

//        ArrayList<Employee> list=new ArrayList<>();
//
//        if(skillId!=null && yearsOfService!=null){
//            for (Employee employee : this.employeeRepository.findAll()) {
//                boolean pass=false;
//                int curr_year= Math.toIntExact(ChronoUnit.YEARS.between(employee.getEmploymentDate(), LocalDate.now()));
//                if(curr_year > yearsOfService){
//                    for (Skill skill : employee.getSkills()) {
//                        if(Objects.equals(skill.getId(), skillId)){
//                            pass=true;
//                            break;
//                        }
//                    }
//                }
//                if(pass)list.add(employee);
//            }
//        }
//        else if(skillId!=null){
//            for (Employee employee : this.employeeRepository.findAll()) {
//                boolean pass=false;
//
//                for (Skill skill : employee.getSkills()) {
//                    if(Objects.equals(skill.getId(), skillId)){
//                        pass=true;
//                        break;
//                    }
//                }
//
//                if(pass)list.add(employee);
//            }
//        }else if(yearsOfService!=null){
//            for (Employee employee : this.employeeRepository.findAll()) {
//                boolean pass=false;
//                int curr_year= Math.toIntExact(ChronoUnit.YEARS.between(employee.getEmploymentDate(), LocalDate.now()));
//                if(curr_year > yearsOfService){
//                    pass=true;
//                }
//                if(pass)list.add(employee);
//            }
//        }
//
//        else {
//            list.addAll(this.employeeRepository.findAll());
//        }
//        return list;

        if(yearsOfService!=null){
            LocalDate minDate=LocalDate.now().minusYears(yearsOfService);
            System.out.println(minDate);
        }

        Specification<Employee> specification =null;

        if(yearsOfService==null){
            specification = Specification
                    .where( null);
        }
        else {
            specification = Specification
                    .where(filterEquals(Employee.class, "skills.id", skillId))
                    .and(lessThan(Employee.class, "employmentDate", LocalDate.now().minusYears(yearsOfService)));
        }



        return this.employeeRepository.findAll(
                specification,
                PageRequest.of(pageNum, pageSize)
        );

    }
}
