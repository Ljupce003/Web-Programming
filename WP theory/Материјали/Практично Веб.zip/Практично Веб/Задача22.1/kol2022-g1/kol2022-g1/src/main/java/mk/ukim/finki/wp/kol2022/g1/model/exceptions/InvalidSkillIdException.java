package mk.ukim.finki.wp.kol2022.g1.model.exceptions;

public class InvalidSkillIdException extends RuntimeException {
}
