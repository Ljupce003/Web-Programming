package mk.ukim.finki.wp.kol2022.g3.repository;

import mk.ukim.finki.wp.kol2022.g3.model.ForumUser;

public interface ForumUserRepository extends JpaSpecificationRepository<ForumUser,Long> {
}
