package mk.ukim.finki.wp.kol2022.g3.service.Implementations;

import mk.ukim.finki.wp.kol2022.g3.model.ForumUser;
import mk.ukim.finki.wp.kol2022.g3.model.ForumUserType;
import mk.ukim.finki.wp.kol2022.g3.model.Interest;
import mk.ukim.finki.wp.kol2022.g3.model.exceptions.InvalidForumUserIdException;
import mk.ukim.finki.wp.kol2022.g3.repository.ForumUserRepository;
import mk.ukim.finki.wp.kol2022.g3.repository.InterestRepository;
import mk.ukim.finki.wp.kol2022.g3.service.ForumUserService;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

import static mk.ukim.finki.wp.kol2022.g3.service.specifications.FieldFilterSpecification.filterEquals;
import static mk.ukim.finki.wp.kol2022.g3.service.specifications.FieldFilterSpecification.greaterThan;

@Service
public class ForumUserServiceImplemented implements ForumUserService {

    private final ForumUserRepository forumUserRepository;
    private final InterestRepository interestRepository;

    public ForumUserServiceImplemented(ForumUserRepository forumUserRepository, InterestRepository interestRepository) {
        this.forumUserRepository = forumUserRepository;
        this.interestRepository = interestRepository;
    }

    @Override
    public List<ForumUser> listAll() {
        return this.forumUserRepository.findAll();
    }

    @Override
    public ForumUser findById(Long id) {
        return this.forumUserRepository.findById(id).orElseThrow(InvalidForumUserIdException::new);
    }

    @Override
    public ForumUser create(String name, String email, String password, ForumUserType type, List<Long> interestId, LocalDate birthday) {

        List<Interest> interests=this.interestRepository.findAllById(interestId);

        ForumUser forumUser=new ForumUser(name,email,password,type,interests,birthday);

        return this.forumUserRepository.save(forumUser);
    }

    @Override
    public ForumUser update(Long id, String name, String email, String password, ForumUserType type, List<Long> interestId, LocalDate birthday) {

        List<Interest> interests=this.interestRepository.findAllById(interestId);

        ForumUser forumUser=findById(id);

        forumUser.setName(name);
        forumUser.setEmail(email);
        forumUser.setPassword(password);
        forumUser.setType(type);
        forumUser.setInterests(interests);
        forumUser.setBirthday(birthday);

        return this.forumUserRepository.save(forumUser);
    }

    @Override
    public ForumUser delete(Long id) {
        ForumUser forumUser=findById(id);

        this.forumUserRepository.delete(forumUser);

        return forumUser;
    }

    @Override
    public List<ForumUser> filter(Long interestId, Integer age) {
        List<ForumUser> list=new ArrayList<>();

        if(interestId !=null && age!=null){
            for (ForumUser user : this.forumUserRepository.findAll()) {
                int curr_age= Math.toIntExact(ChronoUnit.YEARS.between(user.getBirthday(), LocalDate.now()));
                if(curr_age > age){
                    boolean pass=false;
                    for (Interest interest : user.getInterests()) {
                        if(interest.getId().equals(interestId)){
                            pass=true;
                            break;
                        }
                    }
                    if(pass)list.add(user);
                }
            }
        }
        else if(interestId !=null){
            for (ForumUser user : this.forumUserRepository.findAll()) {
                boolean pass=false;
                for (Interest interest : user.getInterests()) {
                    if(interest.getId().equals(interestId)){
                        pass=true;
                        break;
                    }
                }
                if(pass)list.add(user);
            }
        }
        else if(age!=null){
            for (ForumUser user : this.forumUserRepository.findAll()) {
                int curr_age= Math.toIntExact(ChronoUnit.YEARS.between(user.getBirthday(), LocalDate.now()));
                if(curr_age > age){
                    list.add(user);
                }
            }
        }
        else {
            list.addAll(this.forumUserRepository.findAll());
        }


        return list;
    }
}
