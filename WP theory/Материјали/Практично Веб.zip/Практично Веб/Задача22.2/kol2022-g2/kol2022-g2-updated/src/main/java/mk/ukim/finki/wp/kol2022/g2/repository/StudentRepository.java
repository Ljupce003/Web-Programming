package mk.ukim.finki.wp.kol2022.g2.repository;

import mk.ukim.finki.wp.kol2022.g2.model.Student;

import java.util.List;

public interface StudentRepository extends JpaSpecificationRepository<Student,Long> {

}
