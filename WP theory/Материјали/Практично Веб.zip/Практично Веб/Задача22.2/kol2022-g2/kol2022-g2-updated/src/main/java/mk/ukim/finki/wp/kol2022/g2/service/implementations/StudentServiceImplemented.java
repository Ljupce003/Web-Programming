package mk.ukim.finki.wp.kol2022.g2.service.implementations;

import mk.ukim.finki.wp.kol2022.g2.model.Course;
import mk.ukim.finki.wp.kol2022.g2.model.Student;
import mk.ukim.finki.wp.kol2022.g2.model.StudentType;
import mk.ukim.finki.wp.kol2022.g2.model.exceptions.InvalidCourseIdException;
import mk.ukim.finki.wp.kol2022.g2.model.exceptions.InvalidStudentIdException;
import mk.ukim.finki.wp.kol2022.g2.repository.CourseRepository;
import mk.ukim.finki.wp.kol2022.g2.repository.StudentRepository;
import mk.ukim.finki.wp.kol2022.g2.service.CourseService;
import mk.ukim.finki.wp.kol2022.g2.service.StudentService;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

@Service
public class StudentServiceImplemented implements StudentService {

    private final StudentRepository studentRepository;
    private final CourseRepository courseRepository;

    public StudentServiceImplemented(StudentRepository studentRepository, CourseRepository courseRepository) {
        this.studentRepository = studentRepository;
        this.courseRepository = courseRepository;
    }

    @Override
    public List<Student> listAll() {
        return this.studentRepository.findAll();
    }

    @Override
    public Student findById(Long id) {
        return this.studentRepository.findById(id).orElseThrow(InvalidStudentIdException::new);
    }

    @Override
    public Student create(String name, String email, String password, StudentType type, List<Long> courseId, LocalDate enrollmentDate) {

        List<Course> courses= this.courseRepository.findAllById(courseId);

        Student student=new Student(name,email,password,type,courses,enrollmentDate);

        return this.studentRepository.save(student);
    }

    @Override
    public Student update(Long id, String name, String email, String password, StudentType type, List<Long> coursesId, LocalDate enrollmentDate) {

        List<Course> courses= this.courseRepository.findAllById(coursesId);

        Student student=findById(id);

        student.setName(name);
        student.setEmail(email);
        student.setPassword(password);
        student.setType(type);
        student.setCourses(courses);
        student.setEnrollmentDate(enrollmentDate);

        return this.studentRepository.save(student);
    }

    @Override
    public Student delete(Long id) {
        Student student=findById(id);
        this.studentRepository.delete(student);
        return student;
    }

    @Override
    public List<Student> filter(Long courseId, Integer yearsOfStudying) {
        List<Student> list=new ArrayList<>();

        if(courseId!=null && yearsOfStudying!=null){
            for (Student student : this.studentRepository.findAll()) {
                int curr_year= Math.toIntExact(ChronoUnit.YEARS.between(student.getEnrollmentDate(), LocalDate.now()));
                if(yearsOfStudying<curr_year){
                    boolean pass=false;
                    for (Course course : student.getCourses()) {
                        if(course.getId().equals(courseId)){
                            pass=true;
                            break;
                        }
                    }
                    if(pass)list.add(student);
                }
            }
        }
        else if(courseId!=null){
            for (Student student : this.studentRepository.findAll()) {
                boolean pass=false;
                for (Course course : student.getCourses()) {
                    if(course.getId().equals(courseId)){
                        pass=true;
                        break;
                    }
                }
                if(pass)list.add(student);
            }
        }
        else if(yearsOfStudying!=null){
            for (Student student : this.studentRepository.findAll()) {
                int curr_year= Math.toIntExact(ChronoUnit.YEARS.between(student.getEnrollmentDate(), LocalDate.now()));
                if(yearsOfStudying<curr_year){
                    list.add(student);
                }
            }
        }
        else {
            list.addAll(this.studentRepository.findAll());
        }

        return list;
    }
}
