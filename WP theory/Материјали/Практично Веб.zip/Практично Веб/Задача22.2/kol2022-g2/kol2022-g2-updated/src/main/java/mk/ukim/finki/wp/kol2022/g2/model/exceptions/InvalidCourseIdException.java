package mk.ukim.finki.wp.kol2022.g2.model.exceptions;

public class InvalidCourseIdException extends RuntimeException {
}
