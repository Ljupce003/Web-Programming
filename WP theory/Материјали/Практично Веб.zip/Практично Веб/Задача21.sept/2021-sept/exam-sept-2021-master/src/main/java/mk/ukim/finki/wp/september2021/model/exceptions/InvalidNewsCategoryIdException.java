package mk.ukim.finki.wp.september2021.model.exceptions;

public class InvalidNewsCategoryIdException extends RuntimeException {
}
