package mk.ukim.finki.wp.september2021.repository;

import mk.ukim.finki.wp.september2021.model.News;

public interface NewsRepository extends JpaSpecificationRepository<News,Long> {
}
